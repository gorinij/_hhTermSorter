package ru.yaal.project.hhapi.dictionary.entry.entries.proffield;

public class Specialization extends ProfField {
    public static final Specialization NULL_SPECIALIZATION = new Specialization();
}
