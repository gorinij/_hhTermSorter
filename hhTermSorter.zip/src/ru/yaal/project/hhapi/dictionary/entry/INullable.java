package ru.yaal.project.hhapi.dictionary.entry;

public interface INullable {
    boolean isNull();
}
