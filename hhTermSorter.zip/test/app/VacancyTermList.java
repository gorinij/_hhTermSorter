package app;

import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author gorjnich
 */
public class VacancyTermList extends ArrayList<HashSet<String>> {}
