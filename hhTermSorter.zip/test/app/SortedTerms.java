package app;

import java.util.Map;
import java.util.SortedSet;

/**
 *
 * @author gorjnich
 */
@Deprecated
public abstract class SortedTerms implements SortedSet<Map.Entry<String, Integer>> {}
