package app;

import java.util.ArrayList;

/**
 *
 * @author gorjnich
 */
public class VacancyDescriptionList extends ArrayList<String> {}
